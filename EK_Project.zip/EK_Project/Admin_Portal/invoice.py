from flask import Flask, render_template, request, redirect, url_for, Blueprint

app = Flask(__name__)
invoice_bp = Blueprint('invoice', __name__)

# Dummy data for customers and invoices (Replace this with actual database)
customers = [
    {"id": 1, "name": "John Doe"},
    {"id": 2, "name": "Jane Smith"}
]

invoices = [
    {"id": 1, "customer_id": 1, "date": "2024-03-13", "amount": 100.00, "status": "Unpaid"},
    {"id": 2, "customer_id": 2, "date": "2024-03-14", "amount": 150.00, "status": "Paid"}
]

@invoice_bp.route('/invoice')
def list_invoices():
    return render_template('list_invoices.html', invoices=invoices)

@invoice_bp.route('/invoice/create', methods=['GET', 'POST'])
def create_invoice():
    if request.method == 'POST':
        # Assuming form fields have 'customer', 'date', 'amount', 'status'
        new_invoice = {
            'id': len(invoices) + 1,  # Auto-increment ID
            'customer_id': int(request.form['customer']),
            'date': request.form['date'],
            'amount': float(request.form['amount']),
            'status': request.form['status']
        }
        invoices.append(new_invoice)
        return render_template('list_invoices.html', invoices=invoices)
    return render_template('create_invoice.html', customers=customers)

@invoice_bp.route('/invoice/edit/<int:id>', methods=['GET', 'POST'])
def edit_invoice(id):
    invoice = next((inv for inv in invoices if inv['id'] == id), None)
    if invoice:
        if request.method == 'POST':
            # Update invoice details
            invoice['customer_id'] = int(request.form['customer'])
            invoice['date'] = request.form['date']
            invoice['amount'] = float(request.form['amount'])
            invoice['status'] = request.form['status']
            return render_template('list_invoices.html', invoices=invoices)
        return render_template('edit_invoice.html', invoice=invoice, customers=customers)
    return 'Invoice not found', 404

if __name__ == '__main__':
    invoice_bp.run(debug=True)
