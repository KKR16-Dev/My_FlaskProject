from flask import Flask, render_template, request, redirect, url_for, jsonify, Blueprint
from customer import customer_bp
from invoice import invoice_bp

app = Flask(__name__)
api = Blueprint('api', __name__)

# Database simulation (Replace this with actual database)
users = {
    'admin': 'password123'
}

# Dummy data for customers and invoices (Replace this with actual database)
customers = [
    {"id": 1, "name": "John Doe"},
    {"id": 2, "name": "Jane Smith"}
]

invoices = [
    {"id": 1, "customer_id": 1, "date": "2024-03-13", "amount": 100.00, "status": "Unpaid"},
    {"id": 2, "customer_id": 2, "date": "2024-03-14", "amount": 150.00, "status": "Paid"}
]

@app.route('/')
def login():
    return render_template('login.html')

@app.route('/authenticate', methods=['POST'])
def authenticate():
    username = request.form['username']
    password = request.form['password']

    if username in users and users[username] == password:
        # Successful login
        return redirect(url_for('admin_portal'))
    else:
        # Failed login
        return render_template('login.html', error=True)

@app.route('/admin')
def admin_portal():
    return render_template('admin.html')


# @api.route('/customer', methods=['GET', 'POST'])
# def customers_api():
#     if request.method == 'GET':
#         return jsonify(customers)
#     elif request.method == 'POST':
#         new_customer = request.json
#         new_customer['id'] = len(customers) + 1
#         customers.append(new_customer)
#         return jsonify(new_customer), 201

# @api.route('/invoice', methods=['GET', 'POST'])
# def invoices_api():
#     if request.method == 'GET':
#         return jsonify(invoices)
#     elif request.method == 'POST':
#         new_invoice = request.json
#         new_invoice['id'] = len(invoices) + 1
#         invoices.append(new_invoice)
#         return jsonify(new_invoice), 201
    
app.register_blueprint(api, url_prefix='/api')
app.register_blueprint(customer_bp)
app.register_blueprint(invoice_bp)


if __name__ == '__main__':
    app.run(debug=True)
