from flask import Flask, render_template, request, redirect, url_for,Blueprint

app = Flask(__name__)
customer_bp = Blueprint('customer', __name__)

# Dummy customer data (Replace this with actual database)
customers = [
    {"id": 1, "name": "John Doe", "phone": "123-456-7890", "email": "john@example.com", "address": "123 Main St"},
    {"id": 2, "name": "Jane Smith", "phone": "987-654-3210", "email": "jane@example.com", "address": "456 Elm St"}
]

@customer_bp.route('/customer')
def list_customers():
    return render_template('list_customers.html', customers=customers)

@customer_bp.route('/customer/create', methods=['GET', 'POST'])
def create_customer():
    if request.method == 'POST':
        # Assuming form fields have 'name', 'phone', 'email', 'address'
        new_customer = {
            'id': len(customers) + 1,  # Auto-increment ID
            'name': request.form['name'],
            'phone': request.form['phone'],
            'email': request.form['email'],
            'address': request.form['address']
        }
        customers.append(new_customer)
        return render_template('list_customers.html', customers=customers)
    return render_template('create_customer.html')

@customer_bp.route('/customer/edit/<int:id>', methods=['GET', 'POST'])
def edit_customer(id):
    customer = next((c for c in customers if c['id'] == id), None)
    if customer:
        if request.method == 'POST':
            # Update customer details
            customer['name'] = request.form['name']
            customer['phone'] = request.form['phone']
            customer['email'] = request.form['email']
            customer['address'] = request.form['address']
            return render_template('list_customers.html', customers=customers)
        return render_template('edit_customer.html', customer=customer)
    return 'Customer not found', 404

if __name__ == '__main__':
    customer_bp.run(debug=True)
